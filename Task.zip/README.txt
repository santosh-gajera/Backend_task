1) create order : 
url  : http://prayaswelfarefoundation.org/test_task/api/create_order
method : post
parameter : store_id:1 (you can use 1 to 5 store_id)
			order_value:20
			
response : 
{
    "order_data": {
        "order_id": "2",
        "order_date": "2021-08-16",
        "order_price": "20",
        "status": "1",
        "store_id": "1",
        "creation_datetime": "2021-08-16 03:47:53",
        "update_datetime": "0000-00-00 00:00:00"
    },
    "message": "Successfully created order..!!",
    "error": true
}

2) update order status / cancel order: 
url  : http://prayaswelfarefoundation.org/test_task/api/update_order_status
method : post
parameter : order_id:1
			status:2 ( /* 2=shipped,3=cancel */)
			
response : 
{
    "order_data": {
        "order_id": "1",
        "order_date": "2021-08-16",
        "order_price": "20",
        "status": "2",
        "store_id": "1",
        "creation_datetime": "2021-08-16 03:46:11",
        "update_datetime": "2021-08-16 03:53:44"
    },
    "message": "Successfully changed order status..!!",
    "success": true
}

3) 	get order detail by id : 
url  : http://prayaswelfarefoundation.org/test_task/api/get_order_byID
method : post
parameter : order_id:1
			
response : 
{
    "order_data": {
        "order_id": "1",
        "order_date": "2021-08-16",
        "order_price": "20",
        "status": "2",
        "store_id": "1",
        "creation_datetime": "2021-08-16 03:46:11",
        "update_datetime": "2021-08-16 03:53:44",
        "store_name": "store1"
    },
    "message": "Found order details.",
    "success": true
}

4) 		get order list by status filter : 
url  : http://prayaswelfarefoundation.org/test_task/api/get_order_list
method : post
parameter : status:3 (( /* 1=new,2=shipped,3=cancel */))
			
response : if status is blank then get all order list otherwise order display according its status. 
{
    "order_data": [
        {
            "order_id": "1",
            "order_date": "2021-08-16",
            "order_price": "20",
            "status": "3",
            "store_id": "1",
            "creation_datetime": "2021-08-16 03:46:11",
            "update_datetime": "2021-08-16 04:07:28",
            "store_name": "store1"
        },
        {
            "order_id": "2",
            "order_date": "2021-08-16",
            "order_price": "20",
            "status": "3",
            "store_id": "2",
            "creation_datetime": "2021-08-16 03:47:53",
            "update_datetime": "2021-08-16 04:08:33",
            "store_name": "store2"
        }
    ],
    "message": "order list found.",
    "success": true
}

5) 			get order total revenue  : 
url  : http://prayaswelfarefoundation.org/test_task/api/get_order_total_revenue
method : post
parameter : from_date( /* use date format (yyyy-mm-dd) (2021-08-16)*/)
			to_date: 2021-08-16
response : 
{
    "order_total_revenue": "53",
    "message": "calculate total order revenue.",
    "success": true
}