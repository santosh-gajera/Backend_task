<?php defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH.'/libraries/api/REST_Controller.php';
class Api extends REST_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('mdl_common');
	}
	
/*=================================================================================
								create order
==================================================================================*/
	
	function create_order_post()
    {		
		$order_value = $this->post('order_value');
		$store_id = $this->post('store_id');

		$user_data = array('store_id', 'order_value');
		$validation = $this->mdl_common->param_validation($user_data, $this->post());
		
		if($validation['error'] == 'true')
		{			
			$this->response($validation);
		}

		$store_data = $this->mdl_common->get_record('tbl_store','store_id = '.$store_id)->row_array();
		
		if(empty($store_data))
		{
			$response['message']	="store is not registerd with us.";
			$response['error']		= false;
			$this->response($response, 200);
		}
		
		$order_data = array(
			'store_id'	=> $store_id,
			'status'	=> '1',
			'order_date'	=> date('Y-m-d'),
			'order_price'	=> $order_value,
			'creation_datetime'	=> date('Y-m-d h:i:s')
		);
		$order_id = $this->mdl_common->insert_record('tbl_order',$order_data);
		if($order_id)
		{
			$order_data = $this->mdl_common->get_record('tbl_order','order_id = '.$order_id)->row_array();
		
			$response['order_data'] = $order_data;
			$response['message']	="Successfully created order..!!";
			$response['success']		= true;
		}
		else{
			$response['message']	="something went wromg..!!!";
			$response['success']		= false;
		}
		$this->response($response, 200);			
    }

/*=================================================================================
								update order status
==================================================================================*/
	
function update_order_status_post()
{	
	$order_id = $this->post('order_id');
	$status = $this->post('status'); /* 2=shipped,3=cancel	 */

	$user_data = array('order_id','status');
	$validation = $this->mdl_common->param_validation($user_data, $this->post());
	
	if($validation['error'] == 'true')
	{			
		$this->response($validation);
	}

	$order_data = $this->mdl_common->get_record('tbl_order','order_id = '.$order_id)->row_array();
	
	if(empty($order_data))
	{
		$response['message']	="order is not placed with us.";
		$response['error']		= false;
		$this->response($response, 200);
	}
	
	$order_data = array(
		'order_id'	=> $order_id,
		'status'	=> $status,
		'update_datetime'	=> date('Y-m-d h:i:s')
	);
	$order_status = $this->mdl_common->update_record('tbl_order','order_id = '.$order_id,$order_data);
	if($order_status)
	{
		$order_data = $this->mdl_common->get_record('tbl_order','order_id = '.$order_id)->row_array();
	
		$response['order_data'] = $order_data;
		$response['message']	="Successfully changed order status..!!";
		$response['success']		= true;
	}
	else{
		$response['message']	="something went wromg..!!!";
		$response['success']		= false;
	}
	$this->response($response, 200);			
}
/*=================================================================================
								get order detail by id
==================================================================================*/
	
function get_order_byID_post()
{	
	$order_id = $this->post('order_id');

	$user_data = array('order_id');
	$validation = $this->mdl_common->param_validation($user_data, $this->post());
	
	if($validation['error'] == 'true')
	{			
		$this->response($validation);
	}

	$sql = 'select o.*,s.store_name as store_name
			from tbl_order as o 
			left join tbl_store as s on o.store_id = s.store_id 
			where o.order_id = '.$order_id;

	$order_data = $this->mdl_common->execute_query($sql)->row_array();
	
	if(!empty($order_data))
	{
		$response['order_data']	= $order_data;
		$response['message']	="Found order details.";
		$response['success']	= true;
	
	}else
	{

		$response['message']	="order is not placed with us.";
		$response['success']		= true;
	}
	$this->response($response, 200);			
}

/*=================================================================================
								get order list by status filter
==================================================================================*/
	
function get_order_list_post()
{	
	$status = $this->post('status');
	if($status)
	{
		$sql = "select o.*,s.store_name as store_name
			from tbl_order as o 
			left join tbl_store as s on o.store_id = s.store_id 
			where o.status = '$status'";
	}	
	else{
		$sql = "select o.*,s.store_name as store_name
			from tbl_order as o 
			left join tbl_store as s on o.store_id = s.store_id ";
	}

	$order_data = $this->mdl_common->execute_query($sql)->result_array();
	
	if(!empty($order_data))
	{
		$response['order_data']	= $order_data;
		$response['message']	="order list found.";
		$response['success']	= true;
	
	}else
	{

		$response['message']	="order is not found.";
		$response['success']		= true;
	}
	$this->response($response, 200);			
}

/*=================================================================================
								get order total revenue 
==================================================================================*/
	
function get_order_total_revenue_post()
{	
	$from_date = $this->post('from_date'); /* use date format (2021-08-16)*/
	$to_date = $this->post('to_date');

	$user_data = array('from_date','to_date');
	$validation = $this->mdl_common->param_validation($user_data, $this->post());
	
	if($validation['error'] == 'true')
	{			
		$this->response($validation);
	}
	
	$sql = "select sum(order_price) as order_price
			FROM tbl_order
			WHERE (order_date BETWEEN '$from_date' AND '$to_date')";
	
	$order_data = $this->mdl_common->execute_query($sql)->row_array();
	
	if(!empty($order_data))
	{
		$response['order_total_revenue']	= $order_data['order_price'];
		$response['message']	="calculate total order revenue.";
		$response['success']	= true;
	
	}else
	{

		$response['message']	="something went wrong.";
		$response['success']	= true;
	}
	$this->response($response, 200);			
}

}
?>