<?php
class Mdl_common extends CI_Model
{
	function __construct()
	{
		date_default_timezone_set('Asia/Calcutta');
	}
/*=================================================================================
								API Parameter Validation
==================================================================================*/

	function param_validation($paramarray, $data)
	{
		$NovalueParam = array();
		foreach($paramarray as $val)
		{
			
			if(!array_key_exists($val, $data))
			{
				$NovalueParam[] = $val;
			}
		}
		if(is_array($NovalueParam) && count($NovalueParam)>0)
		{
			$returnArr['error'] = true;
			$returnArr['message'] = 'Sorry, that is not valid input. You missed '.implode(',', $NovalueParam).' parameters';
			return $returnArr;
		}
		else
		{
			$returnArr['error'] = false;
			$returnArr['message'] = '';
			return  $returnArr;;
		}
	}
	

/*=================================================================================
								Get Record	
==================================================================================*/
	
	function execute_query($sql)
	{
		return $q = $this->db->query($sql);
	}
	
/*=================================================================================
								Get Record	
==================================================================================*/
	
	function get_record($table_name, $where, $field='*')
	{
		$this->db->select($field, false);
		$this->db->from($table_name);
		
		if(is_array($where))
		{
			foreach($where as $key=>$val)
			{
				$this->db->where($key, $val);
			}
		}
		else
		{
			$this->db->where($where);
		}
		
		return $res=$this->db->get();
	}	
	
/*=================================================================================
								Insert Record	
==================================================================================*/
	
	function insert_record($table_name, $insert_data)
	{
		$this->db->insert($table_name, $insert_data);
		return $this->db->insert_id();
	}	
	
/*=================================================================================
								Update Record	
==================================================================================*/
	
	function update_record($table_name, $where, $update_data)
	{
		if(is_array($where))
		{
			foreach($where as $key=>$val)
			{
				$this->db->where($key, $val);
			}
		}
		else
		{
			$this->db->where($where);
		}
		return $this->db->update($table_name, $update_data);
	}	
	
/*=================================================================================
								Delete Record
==================================================================================*/
	
	function delete_record($table_name, $where)
	{
		if(is_array($where))
		{
			foreach($where as $key=>$val)
			{
				$this->db->where($key, $val);
			}
		}
		else
		{
			$this->db->where($where);
		}
		
		return $this->db->delete($table_name);
	}
	
}
?>